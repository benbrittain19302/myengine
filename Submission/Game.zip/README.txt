CONTROLS:

W - Move Forward
A - Move Left
S - Move Backwards
D - Move Right

Q - Rotate Right
E - Rotate Left

R - Rotate Camera Up
F - Rotate Camera Down

Space - Fly Up
LShift - Descend quicker

LCtrl - Switch Camera Shoulder

